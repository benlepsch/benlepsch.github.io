# How to use Parser library:
- Include the parser.h to your program
- Pass the command line string as an input to the parse_from_line() function
- parse_from_line() split the string by whitespace and will return the separate string tokens as a vector<string>